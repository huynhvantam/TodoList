export class description {
    id: number;
    description : string;
    todoid : number;
}