using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Models.Request
{
    public class ModItem
    {
        public int Id { get; set; }
        public string ItemName { get; set; }
        public bool isfinished { get; set; }
        
    }
}