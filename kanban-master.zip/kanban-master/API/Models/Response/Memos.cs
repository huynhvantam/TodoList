using System.Data.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Models.Response
{
    public class Memos
    {
        public int id { get; set; }
        public string content { get; set; }
    }
}