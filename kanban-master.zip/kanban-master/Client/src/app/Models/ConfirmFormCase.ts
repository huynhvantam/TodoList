export class CC {
    Id: number;
    // ID = 1 :delete
    // Id = 2 : mod board name
    // Id = 3 : mod todo name
}