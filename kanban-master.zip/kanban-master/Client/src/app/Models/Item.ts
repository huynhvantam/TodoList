export class Item{
    id:number;
    itemName:string;
    isfinished:boolean;
    todoid:number;
}