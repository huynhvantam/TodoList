
export class Board {
    id: number;
    boardName: string;
}