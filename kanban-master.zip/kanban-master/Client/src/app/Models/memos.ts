export class memo {
    id: number;
    content : string;
    todoid : number;
}