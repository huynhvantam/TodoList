export const apiurl = {
    URL: "https://192.168.145.97:5001/api"
}