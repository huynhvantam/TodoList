export class Todo {
    id: number;
    todoName:string;
    prio:number;
    deadline:Date;
    deadLineStatus:boolean;
    boardId:number;
}