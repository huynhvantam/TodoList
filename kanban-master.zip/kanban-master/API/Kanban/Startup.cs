using System.Net.Mime;
using System.Collections.Immutable;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RepoInterface;
using Repo;
using ServicesInterface;
using Services;
using Microsoft.AspNetCore.Authentication.Certificate;

namespace Kanban
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddCors();
            services.AddTransient<ITodoRepo, TodoRepo>();
            services.AddTransient<IBoardRepo, BoardRepo>();
            services.AddTransient<IItemRepo, ItemRepo>();
            services.AddTransient<ITodoServices, TodoServices>();
            services.AddTransient<IBoardServices, BoardServices>();
            services.AddTransient<IItemServices, ItemServices>();
            services.AddTransient<IMemosRepo,MemosRepo>();
            services.AddTransient<IMemosServices,MemosServices>();
            
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseCors(Builder =>
            {
                Builder.AllowAnyHeader();
                Builder.AllowAnyMethod();
                Builder.AllowAnyOrigin();
            });
            app.UseStaticFiles();

            app.UseHttpsRedirection();
            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
